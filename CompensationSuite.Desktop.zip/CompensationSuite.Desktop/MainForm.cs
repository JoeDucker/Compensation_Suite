﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace CompensationSuite.Desktop
{
    public partial class MainForm : Form
    {
        private readonly string _cs = ConfigurationManager.ConnectionStrings["EmployeeDb"].ConnectionString;

        private readonly Dictionary<string, double> _avgByRole =
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

        // third chart (trend) created at runtime
        private readonly Chart chartTrend = new Chart();

        public MainForm()
        {
            InitializeComponent();

            // ===== Layout =====
            panel1.Dock = DockStyle.Top;
            tabControl1.Dock = DockStyle.Fill;
            tabPage1.Padding = new Padding(0);

            gridEmployees.Dock = DockStyle.Fill;
            gridEmployees.RowHeadersVisible = false;
            gridEmployees.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridEmployees.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridEmployees.MultiSelect = false;

            // ===== Events =====
            this.Load += MainForm_Load;
            btnApply.Click += BtnApply_Click;
            btnClear.Click += BtnClear_Click;
            btnExport.Click += BtnExport_Click;
            btnTestAudit.Click += btnTestAudit_Click;

            gridEmployees.CellDoubleClick += GridEmployees_CellDoubleClick;
            gridEmployees.CellFormatting += GridEmployees_CellFormatting;
            gridEmployees.CellContentClick += GridEmployees_CellContentClick;   // real handler
            gridEmployees.SelectionChanged += GridEmployees_SelectionChanged;

            tabControl1.SelectedIndexChanged += TabControl1_SelectedIndexChanged;

            // Some projects still have the Designer wired to gridEmployees_CellContentClick_1.
            // This wrapper keeps that happy if it's still hooked:
            gridEmployees.CellContentClick += gridEmployees_CellContentClick_1;

            // Keep only ONE “Audit: All employees” checkbox
            foreach (Control c in panel1.Controls)
            {
                if (c is CheckBox cb && cb != chkAuditAll &&
                    cb.Text.StartsWith("Audit:", StringComparison.OrdinalIgnoreCase))
                {
                    panel1.Controls.Remove(cb);
                    cb.Dispose();
                }
            }
            if (chkAuditAll != null)
            {
                chkAuditAll.Text = "Audit: All employees";
                chkAuditAll.AutoSize = true;
                chkAuditAll.CheckedChanged -= AuditScopeChanged;
                chkAuditAll.CheckedChanged += AuditScopeChanged;
            }
        }

        // ===== Helpers =====

        // Return a proper SQL parameter value from a ComboBox that may hold a DataRowView or the "<All ...>" text.
        // If it represents "All" -> returns DBNull.Value (so the WHERE passes).
        private object GetNullableSelectedValue(ComboBox combo, string valueColumn)
        {
            if (combo.SelectedValue == null || combo.SelectedValue is DBNull) return DBNull.Value;

            if (combo.SelectedValue is DataRowView drv)
            {
                return drv.Row.Table.Columns.Contains(valueColumn)
                    ? drv[valueColumn]
                    : (object)DBNull.Value;
            }

            var text = combo.Text?.Trim() ?? "";
            if (text.StartsWith("<All", StringComparison.OrdinalIgnoreCase)) return DBNull.Value;

            return combo.SelectedValue;
        }

        private void ShowDbBannerAndSanityCheck()
        {
            try
            {
                using var con = new SqlConnection(_cs);
                using var cmd = new SqlCommand(
                    "SELECT COUNT(*) FROM sys.objects WHERE name='Employee_Assignment' AND type='U'", con);
                con.Open();
                var ok = (int)cmd.ExecuteScalar() > 0;
                Text = $"CompensationSuite — {con.DataSource} / {con.Database}";
                if (!ok)
                    MessageBox.Show("Table Employee_Assignment not found in this database.", "Database Warning");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection failed:\n\n" + ex.Message, "Database Error");
            }
        }

        private void EnsureAuditTableExists()
        {
            const string sql = @"
IF OBJECT_ID('dbo.Compensation_Audit','U') IS NULL
BEGIN
    CREATE TABLE dbo.Compensation_Audit
    (
        Audit_ID          INT IDENTITY(1,1) PRIMARY KEY,
        Audit_Ts          DATETIME2(0) NOT NULL CONSTRAINT DF_CompAudit_AuditTs DEFAULT SYSUTCDATETIME(),
        Employee_ID       VARCHAR(10) NOT NULL,
        Old_Compensation  DECIMAL(18,2) NULL,
        New_Compensation  DECIMAL(18,2) NULL,
        Old_Active        CHAR(1) NULL,
        New_Active        CHAR(1) NULL,
        Role_ID           INT NULL,
        Location_ID       INT NULL,
        Changed_By        NVARCHAR(128) NULL,
        Machine_Name      NVARCHAR(128) NULL,
        App_Name          NVARCHAR(128) NULL,
        Reason            NVARCHAR(400) NULL
    );
END";
            try { using var c = new SqlConnection(_cs); using var k = new SqlCommand(sql, c); c.Open(); k.ExecuteNonQuery(); }
            catch { /* ignore; reads will error if truly missing */ }
        }

        // ===== Lifecycle =====

        private void MainForm_Load(object sender, EventArgs e)
        {
            ShowDbBannerAndSanityCheck();
            EnsureAuditTableExists();

            BuildChartsLayout();
            StyleChartsStatic();

            LoadLookups();
            LoadEmployees();
            LoadCompensationChart();
            LoadCompensationByLocationChart();
            LoadTrendChart();
            TryRefreshAuditForCurrent();

            this.WindowState = FormWindowState.Maximized;
        }

        private void BtnApply_Click(object sender, EventArgs e)
        {
            LoadEmployees();
            LoadCompensationChart();
            LoadCompensationByLocationChart();
            LoadTrendChart();
            TryRefreshAuditForCurrent();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            if (cmbRole.Items.Count > 0) cmbRole.SelectedIndex = 0;
            if (cmbLocation.Items.Count > 0) cmbLocation.SelectedIndex = 0;

            LoadEmployees();
            LoadCompensationChart();
            LoadCompensationByLocationChart();
            LoadTrendChart();
            TryRefreshAuditForCurrent();
        }

        // ===== Charts layout / styling =====

        private void BuildChartsLayout()
        {
            chartByLocation.Parent = tabPage2;
            chartCompensation.Parent = tabPage2;

            chartTrend.Parent = tabPage2;
            chartTrend.ChartAreas.Clear();
            chartTrend.ChartAreas.Add(new ChartArea("Trend"));
            chartTrend.Dock = DockStyle.Fill;

            var table = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 3,
                ColumnCount = 1
            };
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 40f)); // pie
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 30f)); // bar
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 30f)); // trend
            table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));

            tabPage2.Controls.Clear();
            tabPage2.Controls.Add(table);

            chartByLocation.Dock = DockStyle.Fill;
            chartCompensation.Dock = DockStyle.Fill;

            table.Controls.Add(chartByLocation, 0, 0);
            table.Controls.Add(chartCompensation, 0, 1);
            table.Controls.Add(chartTrend, 0, 2);
        }

        private void StyleChartsStatic()
        {
            chartByLocation.Palette = ChartColorPalette.SeaGreen;
            chartCompensation.Palette = ChartColorPalette.SeaGreen;
            chartTrend.Palette = ChartColorPalette.SeaGreen;

            foreach (Chart ch in new Chart[] { chartByLocation, chartCompensation, chartTrend })
            {
                if (ch.ChartAreas.Count == 0) ch.ChartAreas.Add(new ChartArea("Main"));
                ch.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Segoe UI", 9f);
                ch.ChartAreas[0].AxisY.LabelStyle.Font = new Font("Segoe UI", 9f);
            }

            chartCompensation.Titles.Clear();
            chartCompensation.Titles.Add(new Title("Average Compensation by Role") { Docking = Docking.Top });

            chartTrend.Titles.Clear();
            chartTrend.Titles.Add(new Title("Average Compensation Trend (by Month)") { Docking = Docking.Top });
        }

        // ===== Lookups =====

        private void LoadLookups()
        {
            // roles
            using (var con = new SqlConnection(_cs))
            using (var da = new SqlDataAdapter("SELECT Role_ID, Role_Name FROM Role ORDER BY Role_Name", con))
            {
                var roles = new DataTable();
                da.Fill(roles);

                var all = roles.Clone();
                var rowAll = all.NewRow();
                rowAll["Role_ID"] = DBNull.Value;
                rowAll["Role_Name"] = "<All Roles>";
                all.Rows.Add(rowAll);
                foreach (DataRow r in roles.Rows) all.ImportRow(r);

                cmbRole.DisplayMember = "Role_Name";
                cmbRole.ValueMember = "Role_ID";
                cmbRole.DataSource = all;
                cmbRole.SelectedIndex = 0;
            }

            // locations
            using (var con = new SqlConnection(_cs))
            using (var da = new SqlDataAdapter("SELECT Location_ID, Location_Name FROM Location ORDER BY Location_Name", con))
            {
                var locs = new DataTable();
                da.Fill(locs);

                var all = locs.Clone();
                var rowAll = all.NewRow();
                rowAll["Location_ID"] = DBNull.Value;
                rowAll["Location_Name"] = "<All Locations>";
                all.Rows.Add(rowAll);
                foreach (DataRow r in locs.Rows) all.ImportRow(r);

                cmbLocation.DisplayMember = "Location_Name";
                cmbLocation.ValueMember = "Location_ID";
                cmbLocation.DataSource = all;
                cmbLocation.SelectedIndex = 0;
            }
        }

        // ===== Grid =====

        private void LoadEmployees()
        {
            const string sql = @"
                SELECT 
                    e.Employee_ID,
                    e.Name,
                    r.Role_Name,
                    l.Location_Name,
                    ea.Compensation,
                    ea.Active,
                    ea.Reference_Date
                FROM Employee_Assignment ea
                INNER JOIN Employee e  ON e.Employee_ID = ea.Employee_ID
                INNER JOIN Role r      ON r.Role_ID     = ea.Role_ID
                INNER JOIN Location l  ON l.Location_ID = ea.Location_ID
                WHERE ea.Active = 'Y'
                  AND (@q = '' OR e.Employee_ID LIKE '%' + @q + '%' OR e.Name LIKE '%' + @q + '%')
                  AND (@roleId IS NULL OR ea.Role_ID = @roleId)
                  AND (@locId  IS NULL OR ea.Location_ID = @locId)
                ORDER BY r.Role_Name, l.Location_Name, e.Name;";

            string q = (txtSearch.Text ?? "").Trim();
            object roleId = GetNullableSelectedValue(cmbRole, "Role_ID");
            object locId = GetNullableSelectedValue(cmbLocation, "Location_ID");

            try
            {
                using (var con = new SqlConnection(_cs))
                using (var cmd = new SqlCommand(sql, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.Parameters.AddWithValue("@q", q);
                    cmd.Parameters.AddWithValue("@roleId", roleId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@locId", locId ?? DBNull.Value);

                    var table = new DataTable();
                    da.Fill(table);
                    gridEmployees.DataSource = table;

                    var colComp = gridEmployees.Columns["Compensation"];
                    if (colComp != null) colComp.DefaultCellStyle.Format = "n0";
                    var colRef = gridEmployees.Columns["Reference_Date"];
                    if (colRef != null) colRef.DefaultCellStyle.Format = "yyyy-MM-dd";
                }

                if (gridEmployees.Rows.Count > 0)
                {
                    if (gridEmployees.CurrentCell == null)
                        gridEmployees.CurrentCell = gridEmployees.Rows[0].Cells[0];

                    if (tabControl1.SelectedTab == tabPage3)
                        TryRefreshAuditForCurrent();
                }

                ComputeRoleAveragesFromGrid();
                gridEmployees.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load data.\n\n" + ex.Message,
                                "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ComputeRoleAveragesFromGrid()
        {
            _avgByRole.Clear();

            var dt = gridEmployees.DataSource as DataTable;
            if (dt == null || dt.Rows.Count == 0) return;

            var sums = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            var counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            foreach (DataRow r in dt.Rows)
            {
                object roleObj = r["Role_Name"];
                object compObj = r["Compensation"];
                if (roleObj == DBNull.Value || compObj == DBNull.Value) continue;

                string role = Convert.ToString(roleObj);
                if (!double.TryParse(Convert.ToString(compObj), out double comp)) continue;

                sums[role] = (sums.TryGetValue(role, out double s) ? s : 0d) + comp;
                counts[role] = (counts.TryGetValue(role, out int c) ? c : 0) + 1;
            }

            foreach (var kvp in sums)
            {
                int c = counts[kvp.Key];
                if (c > 0) _avgByRole[kvp.Key] = kvp.Value / c;
            }
        }

        private void GridEmployees_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = gridEmployees.Rows[e.RowIndex];

            object roleObj, compObj;
            try
            {
                roleObj = row.Cells["Role_Name"].Value;
                compObj = row.Cells["Compensation"].Value;
            }
            catch { return; }

            if (roleObj == null || compObj == null || roleObj is DBNull || compObj is DBNull) return;

            string role = Convert.ToString(roleObj);
            if (!double.TryParse(Convert.ToString(compObj), out double comp)) return;

            if (!_avgByRole.TryGetValue(role, out double avg)) return;

            row.DefaultCellStyle.BackColor = comp >= avg
                ? Color.FromArgb(230, 255, 230)
                : Color.FromArgb(255, 235, 235);
            row.DefaultCellStyle.ForeColor = Color.Black;
        }

        // ===== Charts =====

        private void LoadCompensationChart()
        {
            string q = (txtSearch.Text ?? "").Trim();
            object roleId = GetNullableSelectedValue(cmbRole, "Role_ID");
            object locId = GetNullableSelectedValue(cmbLocation, "Location_ID");

            chartCompensation.Series.Clear();
            chartCompensation.ChartAreas.Clear();
            ChartArea area = new ChartArea("Main");
            chartCompensation.ChartAreas.Add(area);

            Series series = new Series("Avg Compensation by Role")
            {
                ChartType = SeriesChartType.Column,
                XValueType = ChartValueType.String,
                YValueType = ChartValueType.Double,
                IsValueShownAsLabel = true,
                LabelFormat = "N0"
            };

            const string sql = @"
                SELECT r.Role_Name, AVG(CAST(ea.Compensation AS float)) AS AvgComp
                FROM Employee_Assignment ea
                JOIN Employee e  ON e.Employee_ID = ea.Employee_ID
                JOIN Role r      ON r.Role_ID     = ea.Role_ID
                JOIN Location l  ON l.Location_ID = ea.Location_ID
                WHERE ea.Active = 'Y'
                  AND (@q = '' OR e.Employee_ID LIKE '%' + @q + '%' OR e.Name LIKE '%' + @q + '%')
                  AND (@roleId IS NULL OR ea.Role_ID = @roleId)
                  AND (@locId  IS NULL OR ea.Location_ID = @locId)
                GROUP BY r.Role_Name
                ORDER BY r.Role_Name;";

            using (var con = new SqlConnection(_cs))
            using (var cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@q", q);
                cmd.Parameters.AddWithValue("@roleId", roleId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@locId", locId ?? DBNull.Value);

                con.Open();
                using (var rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        string role = Convert.ToString(rdr["Role_Name"]);
                        double avg = Convert.ToDouble(rdr["AvgComp"]);
                        series.Points.AddXY(role, avg);
                    }
                }
            }

            chartCompensation.Series.Add(series);
            chartCompensation.Legends.Clear();

            area.AxisX.Title = "Role";
            area.AxisY.Title = "Average Compensation";
            area.AxisX.Interval = 1;
            area.AxisX.MajorGrid.Enabled = false;
            area.AxisY.MajorGrid.LineColor = Color.Gainsboro;
            area.AxisY.LabelStyle.Format = "N0";
            series["PointWidth"] = "0.6";
            series.ToolTip = "#VALX: #VALY{N0}";
        }

        private void LoadCompensationByLocationChart()
        {
            string q = (txtSearch.Text ?? "").Trim();
            object roleId = GetNullableSelectedValue(cmbRole, "Role_ID");
            object locId = GetNullableSelectedValue(cmbLocation, "Location_ID");

            chartByLocation.Series.Clear();
            chartByLocation.ChartAreas.Clear();

            ChartArea area = new ChartArea("AreaLoc");
            chartByLocation.ChartAreas.Add(area);

            Series series = new Series("Avg by Location")
            {
                ChartType = SeriesChartType.Pie,
                XValueType = ChartValueType.String,
                YValueType = ChartValueType.Double,
                IsValueShownAsLabel = true
            };

            const string sql = @"
                SELECT l.Location_Name, AVG(CAST(ea.Compensation AS float)) AS AvgComp
                FROM Employee_Assignment ea
                JOIN Employee e  ON e.Employee_ID = ea.Employee_ID
                JOIN Role r      ON r.Role_ID     = ea.Role_ID
                JOIN Location l  ON l.Location_ID = ea.Location_ID
                WHERE ea.Active = 'Y'
                  AND (@q = '' OR e.Employee_ID LIKE '%' + @q + '%' OR e.Name LIKE '%' + @q + '%')
                  AND (@roleId IS NULL OR ea.Role_ID = @roleId)
                  AND (@locId  IS NULL OR ea.Location_ID = @locId)
                GROUP BY l.Location_Name
                ORDER BY l.Location_Name;";

            using (var con = new SqlConnection(_cs))
            using (var cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@q", q);
                cmd.Parameters.AddWithValue("@roleId", roleId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@locId", locId ?? DBNull.Value);

                con.Open();
                using (var rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        string loc = Convert.ToString(rdr["Location_Name"]);
                        double avg = Convert.ToDouble(rdr["AvgComp"]);
                        series.Points.AddXY(loc, avg);
                    }
                }
            }

            chartByLocation.Series.Add(series);
            chartByLocation.Legends.Clear();
            chartByLocation.Legends.Add(new Legend
            {
                Docking = Docking.Right,
                Alignment = StringAlignment.Center
            });

            area.InnerPlotPosition.Auto = true;

            series.Label = "#PERCENT{P0}";
            series.ToolTip = "#VALX: #VALY{N0}";
            series.SmartLabelStyle.Enabled = true;
            series["PieLabelStyle"] = "Outside";
            series["PieLineColor"] = "Gray";
            series.BorderWidth = 1;
            series.BorderColor = Color.White;
        }

        private void LoadTrendChart()
        {
            string q = (txtSearch.Text ?? "").Trim();
            object roleId = GetNullableSelectedValue(cmbRole, "Role_ID");
            object locId = GetNullableSelectedValue(cmbLocation, "Location_ID");

            chartTrend.Series.Clear();

            ChartArea area = chartTrend.ChartAreas["Trend"];
            area.AxisX.MajorGrid.Enabled = false;
            area.AxisY.MajorGrid.LineColor = Color.Gainsboro;
            area.AxisY.LabelStyle.Format = "N0";
            area.AxisX.LabelStyle.Format = "yyyy-MM";

            Series s = new Series("Avg per Month")
            {
                ChartType = SeriesChartType.Line,
                XValueType = ChartValueType.Date,
                YValueType = ChartValueType.Double,
                BorderWidth = 2,
                MarkerStyle = MarkerStyle.Circle,
                MarkerSize = 5,
                IsValueShownAsLabel = true,
                LabelFormat = "N0",
                ToolTip = "#VALX{yyyy-MM}: #VALY{N0}"
            };

            const string sql = @"
                SELECT CAST(DATEFROMPARTS(YEAR(ea.Reference_Date), MONTH(ea.Reference_Date), 1) AS date) AS MonthStart,
                       AVG(CAST(ea.Compensation AS float)) AS AvgComp
                FROM Employee_Assignment ea
                JOIN Employee e  ON e.Employee_ID = ea.Employee_ID
                JOIN Role r      ON r.Role_ID     = ea.Role_ID
                JOIN Location l  ON l.Location_ID = ea.Location_ID
                WHERE (@q = '' OR e.Employee_ID LIKE '%' + @q + '%' OR e.Name LIKE '%' + @q + '%')
                  AND (@roleId IS NULL OR ea.Role_ID = @roleId)
                  AND (@locId  IS NULL OR ea.Location_ID = @locId)
                GROUP BY YEAR(ea.Reference_Date), MONTH(ea.Reference_Date)
                ORDER BY MonthStart;";

            using (var con = new SqlConnection(_cs))
            using (var cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@q", q);
                cmd.Parameters.AddWithValue("@roleId", roleId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@locId", locId ?? DBNull.Value);

                con.Open();
                using (var rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        DateTime month = Convert.ToDateTime(rdr["MonthStart"]);
                        double avg = Convert.ToDouble(rdr["AvgComp"]);
                        s.Points.AddXY(month, avg);
                    }
                }
            }

            chartTrend.Series.Add(s);
        }

        // ===== Export CSV =====

        private void BtnExport_Click(object sender, EventArgs e)
        {
            if (gridEmployees.DataSource == null)
            {
                MessageBox.Show("No data to export.");
                return;
            }

            using (var sfd = new SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                FileName = "Employees.csv"
            })
            {
                if (sfd.ShowDialog() != DialogResult.OK) return;

                DataTable dt = gridEmployees.DataSource as DataTable ?? GetDataTableFromGrid(gridEmployees);

                using (var w = new System.IO.StreamWriter(sfd.FileName, false, System.Text.Encoding.UTF8))
                {
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        if (i > 0) w.Write(",");
                        w.Write(dt.Columns[i].ColumnName);
                    }
                    w.WriteLine();

                    foreach (DataRow row in dt.Rows)
                    {
                        for (int i = 0; i < dt.Columns.Count; i++)
                        {
                            if (i > 0) w.Write(",");
                            string cell = row[i] == null ? "" : row[i].ToString().Replace("\"", "\"\"");
                            w.Write("\"" + cell + "\"");
                        }
                        w.WriteLine();
                    }
                }

                MessageBox.Show("Exported successfully.");
            }
        }

        private static DataTable GetDataTableFromGrid(DataGridView grid)
        {
            var dt = new DataTable();
            foreach (DataGridViewColumn col in grid.Columns)
                dt.Columns.Add(col.HeaderText);

            foreach (DataGridViewRow row in grid.Rows)
            {
                if (row.IsNewRow) continue;
                object[] cells = new object[grid.Columns.Count];
                for (int i = 0; i < cells.Length; i++)
                    cells[i] = row.Cells[i].Value;
                dt.Rows.Add(cells);
            }
            return dt;
        }

        // ===== Inline edit (audit proc) =====

        private void GridEmployees_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = gridEmployees.Rows[e.RowIndex];

            string empId = Convert.ToString(row.Cells["Employee_ID"].Value);
            string name = Convert.ToString(row.Cells["Name"].Value);

            decimal currentComp = 0m;
            if (decimal.TryParse(Convert.ToString(row.Cells["Compensation"].Value),
                                 NumberStyles.Any,
                                 CultureInfo.CurrentCulture,
                                 out decimal parsed))
            {
                currentComp = parsed;
            }

            string active = Convert.ToString(row.Cells["Active"].Value);

            using (var dlg = new EditCompensationDialog(empId, name, currentComp, active == "Y"))
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                const string sql = "dbo.usp_UpdateCompensationWithAudit";

                try
                {
                    using (var con = new SqlConnection(_cs))
                    using (var cmd = new SqlCommand(sql, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Employee_ID", empId);
                        cmd.Parameters.AddWithValue("@NewCompensation", dlg.NewCompensation);
                        cmd.Parameters.AddWithValue("@NewActive", dlg.IsActive ? "Y" : "N");
                        cmd.Parameters.AddWithValue("@Reason", (object)dlg.Reason ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@ChangedBy", Environment.UserName);
                        cmd.Parameters.AddWithValue("@MachineName", Environment.MachineName);
                        cmd.Parameters.AddWithValue("@AppName", Application.ProductName);
                        cmd.Parameters.AddWithValue("@ReferenceDate", DateTime.Today);

                        con.Open();
                        cmd.ExecuteNonQuery();
                    }

                    LoadEmployees();
                    LoadCompensationChart();
                    LoadCompensationByLocationChart();
                    LoadTrendChart();
                    TryRefreshAuditForCurrent();

                    MessageBox.Show("Updated with audit.", "Saved",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Update failed:\n\n" + ex.Message,
                        "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Real (no-op) handler for completeness
        private void GridEmployees_CellContentClick(object sender, DataGridViewCellEventArgs e) { }

        // Wrapper for any lingering Designer hook named gridEmployees_CellContentClick_1
        private void gridEmployees_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
            => GridEmployees_CellContentClick(sender, e);

        // ===== Audit tab =====

        private void GridEmployees_SelectionChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab != tabPage3) return;
            TryRefreshAuditForCurrent();
        }

        private void TabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabPage3)
                TryRefreshAuditForCurrent();
        }

        private void AuditScopeChanged(object sender, EventArgs e)
        {
            TryRefreshAuditForCurrent();
        }

        private void TryRefreshAuditForCurrent()
        {
            if (chkAuditAll != null && chkAuditAll.Checked)
            {
                LoadAuditAll();
                return;
            }

            if (gridEmployees.CurrentRow == null)
            {
                gridAudit.DataSource = null;
                tabPage3.Text = "Audit (0)";
                return;
            }

            string emp = Convert.ToString(gridEmployees.CurrentRow.Cells["Employee_ID"].Value);
            if (!string.IsNullOrWhiteSpace(emp))
                LoadAuditForEmployee(emp);
        }

        private void LoadAuditForEmployee(string employeeId)
        {
            const string sqlByEmp = @"
                SELECT TOP 200
                       Audit_Ts,
                       Old_Compensation,
                       New_Compensation,
                       Old_Active,
                       New_Active,
                       Role_ID,
                       Location_ID,
                       Changed_By,
                       Machine_Name,
                       Reason
                FROM dbo.Compensation_Audit
                WHERE Employee_ID = @emp
                ORDER BY Audit_Ts DESC;";

            try
            {
                using (var con = new SqlConnection(_cs))
                using (var cmd = new SqlCommand(sqlByEmp, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.Parameters.AddWithValue("@emp", employeeId);

                    var t = new DataTable();
                    da.Fill(t);
                    gridAudit.DataSource = t;

                    tabPage3.Text = $"Audit ({t.Rows.Count} for {employeeId})";

                    if (gridAudit.Columns["Audit_Ts"] != null)
                        gridAudit.Columns["Audit_Ts"].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss";
                    if (gridAudit.Columns["Old_Compensation"] != null)
                        gridAudit.Columns["Old_Compensation"].DefaultCellStyle.Format = "N0";
                    if (gridAudit.Columns["New_Compensation"] != null)
                        gridAudit.Columns["New_Compensation"].DefaultCellStyle.Format = "N0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load audit.\n\n" + ex.Message,
                    "Audit Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadAuditAll()
        {
            const string sqlAll = @"
                SELECT TOP 500
                       ca.Audit_Ts,
                       ca.Employee_ID,
                       e.Name,
                       ca.Old_Compensation,
                       ca.New_Compensation,
                       ca.Old_Active,
                       ca.New_Active,
                       ca.Role_ID,
                       ca.Location_ID,
                       ca.Changed_By,
                       ca.Machine_Name,
                       ca.Reason
                FROM dbo.Compensation_Audit ca
                LEFT JOIN dbo.Employee e ON e.Employee_ID = ca.Employee_ID
                ORDER BY ca.Audit_Ts DESC;";

            try
            {
                using (var con = new SqlConnection(_cs))
                using (var da = new SqlDataAdapter(sqlAll, con))
                {
                    var t = new DataTable();
                    da.Fill(t);
                    gridAudit.DataSource = t;

                    tabPage3.Text = $"Audit (All: {t.Rows.Count})";

                    if (gridAudit.Columns["Audit_Ts"] != null)
                        gridAudit.Columns["Audit_Ts"].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss";
                    if (gridAudit.Columns["Old_Compensation"] != null)
                        gridAudit.Columns["Old_Compensation"].DefaultCellStyle.Format = "N0";
                    if (gridAudit.Columns["New_Compensation"] != null)
                        gridAudit.Columns["New_Compensation"].DefaultCellStyle.Format = "N0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load (all) audit.\n\n" + ex.Message,
                    "Audit Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ===== Test Audit button =====

        private void btnTestAudit_Click(object sender, EventArgs e)
        {
            if (gridEmployees.CurrentRow == null)
            {
                MessageBox.Show("Select an employee in Data View first.");
                return;
            }

            string empId = Convert.ToString(gridEmployees.CurrentRow.Cells["Employee_ID"].Value);
            if (string.IsNullOrWhiteSpace(empId))
            {
                MessageBox.Show("Could not read Employee_ID from the selected row.");
                return;
            }

            decimal current = 0m;
            decimal.TryParse(Convert.ToString(gridEmployees.CurrentRow.Cells["Compensation"].Value),
                             NumberStyles.Any, CultureInfo.CurrentCulture, out current);
            decimal newComp = current + 1000m;

            try
            {
                using (var con = new SqlConnection(_cs))
                using (var cmd = new SqlCommand("dbo.usp_UpdateCompensationWithAudit", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Employee_ID", empId);
                    cmd.Parameters.AddWithValue("@NewCompensation", newComp);
                    cmd.Parameters.AddWithValue("@NewActive", "Y");
                    cmd.Parameters.AddWithValue("@Reason", "Test audit from app");
                    cmd.Parameters.AddWithValue("@ChangedBy", Environment.UserName);
                    cmd.Parameters.AddWithValue("@MachineName", Environment.MachineName);
                    cmd.Parameters.AddWithValue("@AppName", Application.ProductName);
                    cmd.Parameters.AddWithValue("@ReferenceDate", DateTime.Today);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                LoadEmployees();
                LoadCompensationChart();
                LoadCompensationByLocationChart();
                LoadTrendChart();
                TryRefreshAuditForCurrent();

                MessageBox.Show($"Audit row inserted for {empId}. New comp = {newComp:N0}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Test audit failed:\n\n" + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ===== Edit dialog =====

        private sealed class EditCompensationDialog : Form
        {
            private readonly Label _lblTitle = new Label();
            private readonly NumericUpDown _numComp = new NumericUpDown();
            private readonly CheckBox _chkActive = new CheckBox();
            private readonly TextBox _txtReason = new TextBox();
            private readonly Button _btnOk = new Button();
            private readonly Button _btnCancel = new Button();

            public decimal NewCompensation => _numComp.Value;
            public bool IsActive => _chkActive.Checked;
            public string Reason => _txtReason.Text.Trim();

            public EditCompensationDialog(string empId, string name, decimal currentComp, bool active)
            {
                this.Text = "Edit Compensation";
                this.FormBorderStyle = FormBorderStyle.FixedDialog;
                this.StartPosition = FormStartPosition.CenterParent;
                this.MinimizeBox = false; this.MaximizeBox = false;
                this.ClientSize = new Size(420, 210);

                _lblTitle.AutoSize = true;
                _lblTitle.Text = $"Employee: {empId} — {name}";
                _lblTitle.Left = 12; _lblTitle.Top = 12;

                Label lblComp = new Label { Text = "Compensation:", AutoSize = true, Left = 12, Top = 48 };
                _numComp.Left = 130; _numComp.Top = 44; _numComp.Width = 260;
                _numComp.Maximum = 100000000; _numComp.DecimalPlaces = 0;
                _numComp.ThousandsSeparator = true;
                _numComp.Value = currentComp < 0 ? 0 : currentComp;

                _chkActive.Text = "Active (Y/N)";
                _chkActive.AutoSize = true;
                _chkActive.Left = 12; _chkActive.Top = 80; _chkActive.Checked = active;

                var lblReason = new Label { Text = "Reason (optional):", AutoSize = true, Left = 12, Top = 110 };
                _txtReason.Left = 130; _txtReason.Top = 106; _txtReason.Width = 260;

                _btnOk.Text = "Save"; _btnOk.Width = 90; _btnOk.Left = 210; _btnOk.Top = 150;
                _btnCancel.Text = "Cancel"; _btnCancel.Width = 90; _btnCancel.Left = 300; _btnCancel.Top = 150;

                _btnOk.DialogResult = DialogResult.OK;
                _btnCancel.DialogResult = DialogResult.Cancel;
                this.AcceptButton = _btnOk; this.CancelButton = _btnCancel;

                this.Controls.AddRange(new Control[] {
                    _lblTitle, lblComp, _numComp, _chkActive, lblReason, _txtReason, _btnOk, _btnCancel
                });
            }
        }
    }
}
